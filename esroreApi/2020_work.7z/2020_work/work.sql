select 
a.order_no 已過鑑賞期,
a.PRODUCT_NAME 申辦方案名稱_En,
a.USER_MOBILE connect_co_聯絡方式,
a.ORDER_TYPE 蝦皮訂單型態代碼,
a.MSISDN 門號,
a.ONSALE_NAME 申辦方案名稱_Cn,
a.phone_name 手機品名,
a.phone_type 申辦手機型號,
a.FETNO 申辦手機料號,
a.PREPAYMENT 預繳金,
a.PRODUCT_PRICE 專案手機價,
a.TOTAL_AMOUNT 訂單總金額,
a.CO_STATUS 蝦皮訂單狀態,
a.CROSS_COOPERATION_CREATE_DATE ,
TO_CHAR(m.CO_DATE,'yyyy-mm-dd hh24:mm ss') 遠傳訂單成立日期,
a.USER_NAME 客戶姓名,
a.cono 遠傳訂單編號,
(select count(d.QUANTITY) from CO_DETAIL d where 1=1 and d.cono = m.cono group by d.cono) 庫存量,
m.CO_STATUS  遠傳訂單狀態,
TO_CHAR(m.ACTIVATION_DATE,'yyyy-mm-dd hh24:mm ss') GA或NP啟用日期,
m.CO_TYPE GA或NP狀態 ,
TO_CHAR(m.ACTIVATION_DATE +10,'yyyy-mm-dd hh24:mm ss')鑑賞期_10天,
(
case 
when TO_CHAR(sysdate,'yyyy-mm-dd hh24:mm ss') > TO_CHAR(m.ACTIVATION_DATE +10,'yyyy-mm-dd hh24:mm ss')
then 'Yes'
else 'NO'
end
)已過鑑賞期
from(
select 
order_no,
cono ,
PRODUCT_NAME ,
USER_MOBILE ,
ORDER_TYPE ,
MSISDN ,
ONSALE_NAME ,
'缺' phone_name,
'缺' phone_type,
FETNO ,
PREPAYMENT ,
PRODUCT_PRICE ,
TOTAL_AMOUNT ,
CO_STATUS ,
TO_CHAR(CREATE_DATE,'yyyy-mm-dd hh24:mm ss') CROSS_COOPERATION_CREATE_DATE,
USER_NAME
from
CROSS_COOPERATION
where 1=1
and cono is not null
and TO_CHAR(CREATE_DATE,'yyyy-mm-dd hh24:mm ss') >= '2020-11-11'
)a,CO_MASTER m
where 1=1 
and m.cono = a.cono

